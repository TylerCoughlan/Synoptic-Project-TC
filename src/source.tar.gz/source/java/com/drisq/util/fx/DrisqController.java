package com.drisq.util.fx;

import javafx.scene.Node;

public interface DrisqController {

  Node getRootNode();
}
