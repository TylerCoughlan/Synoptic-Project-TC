package com.drisq.kaptureTest.fx;

import javafx.scene.control.Label;

public class EventSummaryBar {

  private Label nameLabel, paramTypeLabel, descriptionLabel;

  private BarType barType;

  /**
   * Constructs a new CLawZ-summary-row that represents the provided project.
   *
   * @param project the project that this row represents.
   */
  public EventSummaryBar(BarType barType) {
    nameLabel = new Label();
    paramTypeLabel = new Label();
    descriptionLabel = new Label();
  }

  public BarType getBarType() {
    return barType;
  }

  public void createEventBar(String name, String description) {
    nameLabel.setText(name);
    descriptionLabel.setText(description);
  }

  public void createParamBar(String name, String paramType, String description) {
    createEventBar(name, description);
    paramTypeLabel.setText(paramType);
  }

  public Label getNameLabel() {
    return nameLabel;
  }

  public Label getParamTypeLabel() {
    return paramTypeLabel;
  }

  /**
   * Gets the analysis status label for this summary bar
   *
   * @return the analysis status label for this summary bar
   */
  public Label getDescriptionLabel() {
    return descriptionLabel;
  }

  public static enum BarType {
      EVENT, PARAM
  }
}
