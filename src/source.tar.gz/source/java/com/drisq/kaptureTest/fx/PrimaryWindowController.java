package com.drisq.kaptureTest.fx;

import com.drisq.kaptureTest.fx.EventSummaryBar.BarType;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.cell.TreeItemPropertyValueFactory;

public class PrimaryWindowController {

  @FXML
  private Node _rootNode;

  @FXML
  private TreeTableView<EventSummaryBar> _treeTable;

  @FXML
  private TreeTableColumn<EventSummaryBar, Label> _nameColumn;

  @FXML
  private TreeTableColumn<EventSummaryBar, Label> _paramTypeColumn;

  @FXML
  private TreeTableColumn<EventSummaryBar, Label> _descriptionColumn;

  TreeItem<EventSummaryBar> treeRoot;

  @FXML
  private void initialize() {
    treeRoot = new TreeItem<EventSummaryBar>();
    _treeTable.setRoot(treeRoot);
    _treeTable.setShowRoot(false);

    _nameColumn.setCellValueFactory(new TreeItemPropertyValueFactory<EventSummaryBar, Label>("nameLabel"));
    _paramTypeColumn.setCellValueFactory(new TreeItemPropertyValueFactory<EventSummaryBar, Label>("paramTypeLabel"));
    _descriptionColumn
      .setCellValueFactory(new TreeItemPropertyValueFactory<EventSummaryBar, Label>("descriptionLabel"));
    
    populateTestData();
  }

  private void populateTestData() {
    EventSummaryBar loginEvent = new EventSummaryBar(BarType.EVENT);
    loginEvent.createEventBar("LOGIN", "Login event");
    TreeItem<EventSummaryBar> loginEventItem = new TreeItem<EventSummaryBar>(loginEvent);

    EventSummaryBar usernameParam = new EventSummaryBar(BarType.PARAM);
    usernameParam.createParamBar("user_name", "string", "");
    TreeItem<EventSummaryBar> usernameParamItem = new TreeItem<EventSummaryBar>(usernameParam);

    EventSummaryBar userIdParam = new EventSummaryBar(BarType.PARAM);
    userIdParam.createParamBar("user_id", "integer", "");
    TreeItem<EventSummaryBar> userIdParamItem = new TreeItem<EventSummaryBar>(userIdParam);

    EventSummaryBar hostIpParam = new EventSummaryBar(BarType.PARAM);
    hostIpParam.createParamBar("host_ip_address", "string", "");
    TreeItem<EventSummaryBar> hostIpParamItem = new TreeItem<EventSummaryBar>(hostIpParam);

    loginEventItem.getChildren().addAll(usernameParamItem, userIdParamItem, hostIpParamItem);

    EventSummaryBar httpEvent = new EventSummaryBar(BarType.EVENT);
    httpEvent.createEventBar("HTTP", "Web traffic event");
    TreeItem<EventSummaryBar> httpEventItem = new TreeItem<EventSummaryBar>(httpEvent);

    EventSummaryBar srcAddrParam = new EventSummaryBar(BarType.PARAM);
    srcAddrParam.createParamBar("src_ip_address", "string", "");
    TreeItem<EventSummaryBar> srcAddrParamItem = new TreeItem<EventSummaryBar>(srcAddrParam);

    EventSummaryBar destAddrParam = new EventSummaryBar(BarType.PARAM);
    destAddrParam.createParamBar("destination_ip_address", "string", "");
    TreeItem<EventSummaryBar> destAddrParamItem = new TreeItem<EventSummaryBar>(destAddrParam);

    httpEventItem.getChildren().addAll(srcAddrParamItem, destAddrParamItem);

    treeRoot.getChildren().addAll(loginEventItem, httpEventItem);
  }

}
