package com.drisq.kaptureTest.fx;

import java.io.InputStream;
import java.net.URL;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Region;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class GuiLauncher extends Application {

	private static final String FXML_RSC = "rsc/PrimaryWindow.fxml";

	public static void main(String... args) {
		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		URL url = getClass().getResource(FXML_RSC);
		Region root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		stage.setTitle("Cluster Detection Algorithm");
		stage.setScene(scene);
		stage.show();
	}

	private static String[] LIBERATION_FONT_NAMES = new String[] {
			"LiberationMono-BoldItalic.ttf", "LiberationMono-Regular.ttf",
			"LiberationSans-Italic.ttf", "LiberationSerif-Bold.ttf",
			"LiberationMono-Bold.ttf", "LiberationSans-BoldItalic.ttf",
			"LiberationSans-Regular.ttf", "LiberationSerif-Italic.ttf",
			"LiberationMono-Italic.ttf", "LiberationSans-Bold.ttf",
			"LiberationSerif-BoldItalic.ttf", "LiberationSerif-Regular.ttf" };

	private static String[] OTHER_FONTS = new String[] { "525icons.ttf" };

	protected static void loadFonts() {
		for (String fontName : LIBERATION_FONT_NAMES) {
			InputStream stream = GuiLauncher.class
					.getResourceAsStream("/fonts/" + fontName);
			Font font = Font.loadFont(stream, 12);
		}
		for (String fontName : OTHER_FONTS) {
			InputStream stream = GuiLauncher.class
					.getResourceAsStream("/fonts/" + fontName);
			Font font = Font.loadFont(stream, 12);
		}
	}

}
