import com.drisq.kaptureTest.fx.GuiLauncher;

public class ApplicationLauncher {

	public static void main(String[] args) {
		GuiLauncher.main(args);
		System.exit(0);
	}

}
